#ifndef _HUFFMAN_ARCHIVER_H_
#define _HUFFMAN_ARCHIVER_H_

#include <iostream>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <algorithm>
using std::string;

#include "../Interface/Archiver.h"

class Reader;
class Writer;

struct Node
{
    
    Node* l = NULL;
    Node* r = NULL;
    string value = "";
    int Num = 0;    
};
                

class HuffmanArchiver : public Archiver
{ 
    string Code[256];	
    Node Tree[100000];
    Node* Root;
    bool WasBuild;
    unsigned short TreeNum;   	
    unsigned short SymNum;   	
    unsigned char CompStr[100000];    
    //unsigned char Str[100000000];        
    int num[256];
    unsigned short Parent[100000];
    unsigned char Type[100000];
    bool IsSym[100000];
    unsigned char Sym[100000];
    int CompressedIndex;
    int DecompressedIndex;
    int CompressedFileLength;
    int FileLength;  
    static const int OpNum = 100;
    static const int MaxNum = 100000;    
    void CompressInit(Reader *reader, Writer *writer);   
    void TreeSave(Node* v, unsigned short ParentNum, int Type);
    void TreeBuild(Reader *reader, Writer *writer);
    void code(Node* a, string prefix);
    static bool comp(Node a, Node b);
public:    
    HuffmanArchiver();
    ~HuffmanArchiver();     
    void Compress(Reader *reader, Writer *writer);
    void Decompress(Reader *reader, Writer *writer);
    //bool PutNextCompressedPart(Reader *reader, Writer *writer);
    bool PutNextDecompressedPart(Reader *reader, Writer *writer);

};

#endif
