#include "Huffman.h"
#include "../../InputOutput/Interface/Reader.h"
#include "../../InputOutput/Interface/Writer.h"


HuffmanArchiver::HuffmanArchiver()
{
//    std::cout << "CONSTR" << std::endl; 
    for(int i = 0; i < 256; i++)
    Code[i] = "xx";
    for(int i = 0; i < 100000; i++)
    Sym[i] = 'x';
    Root = NULL;
    WasBuild = false;
    TreeNum = 0; 
    SymNum = 0;     
    CompressedIndex = 0;
    DecompressedIndex = 0;
    CompressedFileLength = 0;
    FileLength = 0;    
}
HuffmanArchiver::~HuffmanArchiver()
{
//    std::cout << "DESTR" << std::endl;
}
bool HuffmanArchiver::comp(Node a, Node b)
{
    return (a.Num > b.Num);
}

void HuffmanArchiver::TreeSave(Node* v, unsigned short ParentNum, int type)
{
    Parent[TreeNum] = ParentNum;
    Type[TreeNum] = (unsigned char) (char)type;
    TreeNum++;  
    int  x = TreeNum - 1;
    
    if (v->value.length() > 1)
    {
    TreeSave(v->l, x, 0); 
    TreeSave(v->r, x, 1);    
    } 
    else
    {
    IsSym[x] = true;  
    Sym[x] = (unsigned char)v->value[0];
//    std::cout << x << Sym[x] << std::endl;
    }    

}

void HuffmanArchiver::code(Node* a, string prefix)
{    
    if (a->value.length() == 1)
    {
        Code[(int)a->value[0]] = prefix;
      std:: cout << a->value[0] << " " << prefix << std::endl;
        return;
    }
    code(a->l, prefix + "0");   
    code(a->r, prefix + "1");                            

}
void HuffmanArchiver::CompressInit(Reader *reader, Writer *writer)
{    
    std::cout << "Init"  << std:: endl; 
    FileLength = 0;
    for (int i = 0; i < 256; i++)
        num[i] = 0;
    unsigned char sym;
    std::cout << "Init2"  << std:: endl; 
    while (reader->GetChar(&sym))
    {
      //Str[FileLength] = sym;        
        FileLength++;
        num[(int)sym]++;    
//  std::cout << Str[FileLength-1] << " " << (int)sym << std:: endl;         
    }   
    std::cout << "File length: " << FileLength << std:: endl;         

}
void HuffmanArchiver::Compress(Reader *reader, Writer *writer)
{    
    std::cout << "Compression  start" << std:: endl; 
    Reader *newreader = reader->Clone();
    std::cout << "Clone is done "  << std:: endl; 
    CompressInit(reader,writer);                   

        
    unsigned short n  = 0;
    Node CompTree[100000];

   for(int i = 0; i < 256; i++)
        if (num[i] > 0)
        {
            CompTree[n].value = char(i);
          CompTree[n].Num = 1;         
          CompTree[n].Num = num[i];    
            n++;                        
        } 
    SymNum = n; 
    std::sort(CompTree, CompTree + n, comp);    
    while (n > 1)
    {
        Node* n1 = new Node;
        Node* n2 = new Node;
        *n1 = CompTree[n-2];       
        *n2 = CompTree[n-1];        
        n--;
        CompTree[n-1].l = n1;
        CompTree[n-1].r = n2;
        CompTree[n-1].value = n1->value + n2->value;
        CompTree[n-1].Num = n1->Num + n2->Num;
        std::sort(CompTree, CompTree + n, comp);
    }
    Root = &CompTree[0];    
    for (int i = 0; i < 256; i++)
        Code[i] = "5";
    code(Root, "");
    for (int i = 0; i < MaxNum; i++)
    IsSym[i] = false;
    TreeNum = 0;    
    TreeSave(Root,0,0);
    
    writer->PutShort(TreeNum);    
//    std::cout << TreeNum << " ";
    for(int i = 0; i < TreeNum; i++)
    {
    	writer->PutShort(Parent[i]);
    	writer->PutChar(Type[i]);						
//        std::cout << Parent[i] << "_"<< (int)Type[i] <<" ";
    } 
    writer->PutShort(SymNum);    
    std::cout << SymNum << " "; //
    for(unsigned short i = 0; i < TreeNum; i++)
    {
    if (IsSym[i])
    {
            writer->PutShort(i);
            writer->PutChar(Sym[i]);
            std::cout << i << "_" << Sym[i] << " "; //
    }    
    }
    writer->Flush();
    unsigned char sym;
    bool b;
   while(newreader->GetChar(&sym))
   {       
    int k = int(sym);
        for(size_t j = 0; j < Code[k].length(); j++)
	if (Code[k][j] == '0')
	{
	    b = false;
            writer->PutBit(b);						//CHANGED   
	   std:: cout << b;
	}else	
	{
	    b = true;
            writer->PutBit(b);								
	    	   std:: cout << b;	
	}
	std:: cout << ' ';
    }
    
    writer->Flush();   

//    while(PutNextCompressedPart(reader,writer));        
    std::cout << "Compress is done!" << std:: endl;                                     
}

void HuffmanArchiver::Decompress(Reader *reader, Writer *writer)
{   
    std::cout << "Decompress" << std:: endl;                 
    while (PutNextDecompressedPart(reader,writer)); 
}
bool HuffmanArchiver::PutNextDecompressedPart(Reader *reader, Writer *writer)
{
//    std::cout << "PutDecomp" << std:: endl;         
    if (!WasBuild)
    {
    TreeBuild(reader, writer);
    std::cout << "Build is done" << std::endl;  
    WasBuild = true;
    }                               
    int RNum = 0;
    bool EndOfFile = false; 
    Node* CurNode;
    CurNode = &Tree[0];
    bool sym;
    while(RNum <= OpNum && reader->GetBit(&sym))
    {    
	if (sym == true)
		std::cout << '1';
	else
		std::cout << '0';
    	if (CurNode->value.length() > 1)
        {
            if (!sym)
                CurNode = CurNode->l;
            else
                CurNode = CurNode->r;   
        }
      else
      {
//            std::cout << CurNode->value[0];
            writer->PutChar(CurNode->value[0]);
            RNum++;
            CurNode = &Tree[0];
            if (!sym)
                CurNode = CurNode->l;
            else
                CurNode = CurNode->r;
	if (DecompressedIndex++ > FileLength * 3)
	    break;
      }
      if (CurNode->value.length() == 1 && RNum == OpNum)
      {
            writer->PutChar(CurNode->value[0]); 
            break;
      } 
    } 
    writer->Flush();    
    if (RNum < OpNum)
      EndOfFile = true;        
    return (!EndOfFile);
}


void HuffmanArchiver::TreeBuild(Reader *reader, Writer *writer)
{
    reader->GetShort(&TreeNum);        
//    std:: cout << TreeNum << std::endl;
    unsigned char type,sym;
    unsigned short num;    
    Tree[0].value = "xx"; 
    reader->GetShort(&num);
    reader->GetChar(&type);
    for(int i = 1; i < TreeNum; i++)
    {   
      Tree[i].value = "xx"; 
    reader->GetShort(&num);
    reader->GetChar(&type);
//      std:: cout <<num << "_" << (int)type << " ";
    if (type == 0)
            Tree[num].l = &Tree[i]; 
    else
            Tree[num].r = &Tree[i];
    } 
//    std::cout << std::endl; 
    unsigned short Symnum;


    reader->GetShort(&Symnum);
    std:: cout << Symnum<< " ";//
    for(unsigned short i = 0; i < Symnum; i++)
    {     
      reader->GetShort(&num); 
        reader->GetChar(&sym);
        std:: cout <<num << "_" << sym << " ";//
        Tree[num].value = "x";
        Tree[num].value[0] = sym;
    }

}







